create
    definer = root@localhost procedure dropProducts(IN ID int)
BEGIN
Delete FROM Productss WHERE ID = ID;
end;

