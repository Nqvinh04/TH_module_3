create
    definer = root@localhost procedure productsProc()
Begin
        select * FROM Productss;
    end;

